package com.visma.numbers.helpers;

import java.util.Calendar;
import java.util.Date;

public class DateHelper {
	
	public static int getDayOfWeek() {
		Date now = new Date();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(now);
        int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK); 
        
        if (dayOfWeek <= 7 && dayOfWeek != 1) {
        	return dayOfWeek-1;
        }
        else {
        	return dayOfWeek +6;
        }
	}
}
