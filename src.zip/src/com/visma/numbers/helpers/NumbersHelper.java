package com.visma.numbers.helpers;

import java.util.List;

public class NumbersHelper {
	
	public static void printCountNumbers(List<Integer> numbers) {
		int count = numbers != null ? numbers.size() : 0;    
		System.out.println(count);
	}
	
	public static void printAllNumbers(List<Integer> numbers) {
		if (numbers == null)
			return;	
		
		for(Integer number : numbers) {
		    System.out.println(number);
		} 
	}
	
	public static int divideByWeekDay(List<Integer> numbers, int dayOfWeek) {
		int numberSum = 0;
		
		for (Integer num : numbers) {
			numberSum += num;				
		}
		
		return numberSum / dayOfWeek;
	}
}
