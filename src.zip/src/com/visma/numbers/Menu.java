package com.visma.numbers;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Menu {
	
	private Scanner scan;
	
	public Menu(Scanner scan) {
		this.scan = scan;
	}
	
	public void printMenu() {
		System.out.println("Choose number from the options below:");
		System.out.println("1 - Will sum all the numbers and divide from the week day");
		System.out.println("2 - Will print the size (count) of your entered elements");
		System.out.println("3 - Will print all the elements seperate");
		System.out.println("Any other number will stop the program");
	}
	
	public int scanNumber() {
		int number = 0;
		boolean done = false;
		
		while(!done) {
		try {
			number = this.scan.nextInt();
			done = true;
		} catch(InputMismatchException e) {
			this.scan.nextLine();
			System.out.println("Incorrect number");
			System.out.println("Enter a valid number, whenever you want to finish enter 0:");
		}
		}
		return number;
	}
		
}
