package com.visma.numbers;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.visma.numbers.helpers.DateHelper;
import com.visma.numbers.helpers.NumbersHelper;

public class VismaTask {

	 public static void main(String[] args) {
		Scanner scan = new Scanner (System.in);
		System.out.println("Enter numbers, whenever you want to finish enter 0: ");
		
		Menu menu = new Menu(scan);
		
		List<Integer> numbers = new ArrayList<>();
		int currentNo = menu.scanNumber();
		
		while (currentNo != 0) {
			numbers.add(currentNo);
			currentNo = menu.scanNumber();
		}
		
		while (true) {
		
		menu.printMenu();
		
		int option = menu.scanNumber();
		
		switch(option) {
		
		case 1: 
			int result = NumbersHelper.divideByWeekDay(numbers, DateHelper.getDayOfWeek());
			System.out.println(result);
			break;
		case 2:
			NumbersHelper.printCountNumbers(numbers);
			break;
		case 3:
			NumbersHelper.printAllNumbers(numbers);
			break;
		default:
			return;
		}
	}
}
}
